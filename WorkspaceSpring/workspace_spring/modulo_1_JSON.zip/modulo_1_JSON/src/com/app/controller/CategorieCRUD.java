package com.app.controller;

import java.io.File;

import com.app.model.entity.Categoria;
import com.app.model.entity.Categorie;
import com.app.services.InOutJSON;

public class CategorieCRUD {

	InOutJSON<Categorie> jsonCategorie;
	private File fileCategorie;
	private Categorie categorie;
	private static int contatore;
	
	private CategorieCRUD() {
		super();
		this.jsonCategorie = new InOutJSON<Categorie>();
		this.fileCategorie = new File("c:/json/categorie.json");
		// Riempio categorie leggendo il file XML
		this.categorie = read();
		// Imposto il contatore con l'id dell'ultimo prodotto presente nell'attributo listaCategorie
		if (this.categorie.getListaCategorie().size() != 0) {
			contatore = this.categorie.getListaCategorie().get(this.categorie.getListaCategorie().size() - 1).getId();
		}	
	}
	
	private static CategorieCRUD instance = null;
	
	public static synchronized CategorieCRUD getInstance() {
		if(instance == null) {
			instance = new CategorieCRUD();
		}
		return instance;
	}
	
	public void create(Categoria categoria) {
		if (categoria == null) return;
		contatore += 1;
		categoria.setId(contatore);
		categorie.addCategoria(categoria);
		jsonCategorie.writeJSON(fileCategorie, categorie);
	}
	
	public Categorie read() {
		if (!fileCategorie.exists()) return new Categorie();
		return jsonCategorie.readJSON(fileCategorie, Categorie.class);
	}
}
