package com.app.services;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.eclipse.persistence.jaxb.MarshallerProperties;
import org.eclipse.persistence.jaxb.UnmarshallerProperties;

public class InOutJSON<T> {

	/**
	 * Fa il parsing di un file JSON e ne restituisce l'oggetto descritto.
	 * 
	 * @param fileJSON Il file JSON contenente la descrizione dell'oggetto.
	 * @param objectClass La classe dell'oggetto descritto nel file JSON.
	 * @return Un oggetto del tipo descritto se l'operazione va a buon fine,
	 *         altrimenti null.
	 */
	public T readJSON(File fileJSON, Class<T> objectClass) {
		try {
			JAXBContext jc = JAXBContext.newInstance(objectClass);
			Unmarshaller unmarshaller = jc.createUnmarshaller();
			unmarshaller.setProperty(UnmarshallerProperties.MEDIA_TYPE, "application/json");
			unmarshaller.setProperty(UnmarshallerProperties.JSON_INCLUDE_ROOT, true);
			return (T) unmarshaller.unmarshal(fileJSON);
		} catch (JAXBException e) {
			e.printStackTrace();
			return null;
		}
	}

	/**
	 * Crea un file JSON con la descrizione di un oggetto.
	 * 
	 * @param fileXML Il file XML di output.
	 * @param object Oggetto di cui si vuole la descrizione XML
	 * @return true se l'operazione va a buon fine, altrimenti false.
	 */
	public boolean writeJSON(File fileJSON, T object) {
		try {
			JAXBContext jc = JAXBContext.newInstance(object.getClass());
			Marshaller marshaller = jc.createMarshaller();
	        marshaller.setProperty(MarshallerProperties.MEDIA_TYPE, "application/json");
	        marshaller.setProperty(MarshallerProperties.JSON_INCLUDE_ROOT, true);
	        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.marshal(object, fileJSON);
			return true;
		} catch (JAXBException e) {
			e.printStackTrace();
			return false;
		} catch (NullPointerException e) {
			e.printStackTrace();
			return false;
		} catch (ArrayIndexOutOfBoundsException e) {
			e.printStackTrace();
			return false;
		}	
	}

}
